# checkout-client-library

[![License](https://img.shields.io/badge/license-GPLv2-blue.svg)](https://raw.githubusercontent.com/qenta-cee/checkout-client-library/master/LICENSE)
[![PHP v7.2](https://img.shields.io/badge/php-v7.2-green.svg)](http://www.php.net)
[![PHP v7.3](https://img.shields.io/badge/php-v7.3-green.svg)](http://www.php.net)
[![PHP v7.4](https://img.shields.io/badge/php-v7.4-green.svg)](http://www.php.net)

Client library used by QENTA Checkout Page and Seamless plugins for payment processing.
