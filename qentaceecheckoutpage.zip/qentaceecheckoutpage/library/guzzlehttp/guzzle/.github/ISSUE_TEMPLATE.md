Please consider using one of the issue templates (bug report, feature request).
