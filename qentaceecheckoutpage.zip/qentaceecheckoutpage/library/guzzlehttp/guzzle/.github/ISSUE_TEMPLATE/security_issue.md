---
name: ⛔ Security Issue
about: See the description to report security-related issues
---

⚠ PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, SEE BELOW.

If you have found a security issue in Guzzle, please send the details to
security [at] guzzlephp.org  and don't disclose it publicly until we can provide a
fix for it.
