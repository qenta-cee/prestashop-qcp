---
name: ⛔ Support Question
about: See https://github.com/guzzle/guzzle/blob/master/.github/SUPPORT.md for questions about using Guzzle and its components
---

We use GitHub issues only to discuss about Guzzle bugs and new features.
For this kind of questions about using Guzzle,
please use any of the support alternatives shown in https://github.com/guzzle/guzzle/blob/master/.github/SUPPORT.md

Thanks!
